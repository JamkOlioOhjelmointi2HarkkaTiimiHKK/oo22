#pragma once
#include "MapObject.h"
class SpawnEnemy : public MapObject
{
public:
	SpawnEnemy();
	SpawnEnemy(int, int);
	~SpawnEnemy();
};

