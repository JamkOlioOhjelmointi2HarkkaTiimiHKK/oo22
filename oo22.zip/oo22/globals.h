#ifndef GLOBALS_H
#define GLOBALS_H
#include <iostream>
#include <SFML\Graphics.hpp>
//Ruudun leveys ja korkeus
const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 768;
const char OPTIONS_FILENAME[] = "options.dat";

extern sf::RenderWindow window; //Piirtoikkuna


#endif;