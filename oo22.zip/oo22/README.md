oo22
====

Olio ohjelmointi 2 Harjoitustyö - "Tällä kertaa projekti toivottavasti oikeassa muodossa"-edition

Tavoitteena on luoda 2D peli tasohyppely/roguelike elementeillä. Projekti on luotu täysin opetustarkoitukseen. Käytämme C++ kieltä ja SFML kirjastoa.
