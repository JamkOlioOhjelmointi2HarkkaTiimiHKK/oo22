#pragma once
#include "MapObject.h"

class Floor : public MapObject
{
public:
	Floor();
	Floor(int, int);
	~Floor();
};

