#pragma once
#include "MapObject.h"

class Block : public MapObject
{
public:
	Block();
	Block(int, int);
	~Block();
};

