#pragma once
#include "MapObject.h"
class Ladder : public MapObject
{
public:
	Ladder();
	Ladder(int, int);
	~Ladder();
};

